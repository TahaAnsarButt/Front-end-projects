/*
alert("Alert!")
document.write("this function writes in a document");
console.warn("warning!");
console.error('error');
console.clear();
console.assert(4===2);
console.log (!true);
*/

/*
function average() {
    return (a + b)/2
}
var a =4;
var b =6;
// console.log (average(1,2));
console.log (average())

var a = [0,2,4,6,8];
for(i=0; i<a.length; i++) {
console.log(a[i]);
}

var b = 5;
while(b<a.length) {
    console.log(a[b])
    b++;
}

do{
console.log(a[b])
    b++;
}
while(b<a.length);

*/
/*
a.forEach(element => {
console.log(element)    
});
*/
// a.forEach (function(element) {
// console.log(element);
// })
/*
function avg(a,b) {
    return (a+b)/2;
}
c=avg(4,6);
console.log(c);

function clicked() {
    console.log('clicked on button');
}

window.onload = function() {
    console.log('loaded')
}
    
secondcontainer.addEventListener('click', function() {
    console.log('clicked');
})
secondcontainer.addEventListener('mouseover', function() { 
    console.log('mouse in div');
})
secondcontainer.addEventListener('mouseout', function() {
    console.log('mouse out of div');
    // secondcontainer.setAttribute('style', font-family: Orbitron;
    letter-spacing: 7px;,'background-color: yellow;');
})

document.querySelectorAll('.container').forEach(container => {
    container.addEventListener('mouseout', event => {
      console.log('mouse hover');
    })
  })




secondcontainer.addEventListener('click', function(){
    document.querySelectorAll('.container')[0].innerHTML = '<B>hey</B>';
})


const containers = document.querySelectorAll('.container');
containers.forEach(container => {
    container.addEventListener('mouseover', function handleClick(event) {
    document.querySelectorAll('.container')[0].innerHTML = '<B>hey</B>';
  });
});
*/
var myName = 'Buthal';
myName = 8;
let ourName = 'Javascript intro';
const pi = 3.14;

// Storing Values with the Assignment Operator
var ae;
var be = 3;
ae = 7;
be = ae;
//console.log(ae);

// Initializing Variables with the Assignment Operator
ae = 8;

// Uninitialized Variables
var c;
var d;
var e;

// Basic Math
var sum = 10 + 10;
var subtract = 10 - 10;
var divide = 10 / 10;
var multiply = 10 * 10;
//console.log(sum);

// Increment and Decrement
var myVar = 98;
myVar = myVar + 1;
//console.log(myVar);
myVar++;
//console.log(myVar);
myVar += 1;
//console.log(myVar);
myVar = 100;
//console.log(myVar);
myVar = myVar - 1;
//console.log(myVar);
myVar--;
//console.log(myVar);
myVar -= 1;
//console.log(myVar);

// Finding a Remainder
var Remainder = 10%3;
//console.log(Remainder);

// Augmented Math Operations
var n = 10;
n = n+1;
n+=1;
//console.log(l);

// Declare String Variables
var myName = "Buthal";

// Escaping Literal Quotes

// Quoting Strings with Single Quotes

// Escape Sequences

// Plus Operator
var nwStr = 'h'+'mm';
//console.log(nwStr);

// Concatenating Strings with Variables
var jj = 'one';
var zz = 'two'+jj;
//var m = jj + zz;
//console.log(zz);

// nth character
firstchar = 'aja';
lastcharoffirstchar = firstchar[firstchar.length -1];
//console.log(lastcharoffirstchar);

//word Blanks
function wordBlanks(noun,adjective,verb,adverb) {
    result = ''
    result += 'the' + adjective + noun + verb + adverb; 
    return result;
}
//console.log(wordBlanks('dog', 'slow' ,'jump','fence'));

// access data from multidimesional arrays
var onearr = [[0,1,2],[1,2,3,],[[1],[2]]]
var dat = onearr[2][0];
//console.log(dat);

// push()
var newArr = ['happy', 'budgie'];
newArr.push(57);
//console.log(newArr);

// pop()

// shift()

// unshift()

// functions
function f() {
    //console.log('second function')
}
//f();

// Arguments parameters are variables that act as a place holder for the values that are to be input to a function when it is to be called

function r(a,b) {
//    console.log(a+b)
}
//r(10,9);

// scope of global variable
var myGlobal=10;

function fun1() {
    oopsGlobal=5;
}
function fun2() {
    var output = "";
    if(typeof myGlobal != "undefined") {
        output += "myGlobal: " + myGlobal;
    }
    if(typeof oopsGlobal != "undefined") {
        output += "oopsGlobal" + oopsGlobal;
    }
    //console.log(output);
}
//fun1();
//fun2();

//
var item1 = 'pants';
function locvsglobal() {
    var item2 = item1;
    //console.log(item2);
}
//console.log(item2);
locvsglobal();

var outwear = "T-shirt";
function myFit() {
    outwear = "Jersey";
    return outwear;
}
//console.log(myFit());
//console.log(outwear);

// Stand in line
function nextInLine(arr, item) {
    arr.push(item);
    return arr.shift();
}
var testarr = [0,1,2,3,4,5]
//console.log("Before: "+ JSON.stringify(testarr));
//console.log(nextInLine(testarr,6));
//console.log("After: "+ JSON.stringify(testarr));

// Strict equality operator
function op(a,b) {
    if(a===b) {
        return 'true';
    }
    return 'false';
}
//console.log(op(10,'10'));

// Switch
function sw1(val) {
    var answer='';
    switch (val) {
        case 1:
            answer = '1'
            break;
    
        default:
            answer = 'huh'
            break;
            case 2:
                answer = '2'
                break;
    }
    //return answer;
}
//console.log(sw1(4));

// Convert if else chain into a switch
function chn(valu) {
    var anr="";

    switch(valu) {
        case 1 : '4'
        anr = 'bob';
        break;
        case 2: '1'
        anr = 'marley';
        break;
    }
    
} 

var count = '0'
function cc(card) {
    switch(card)
    {
        case 1: 
        case 2:
        count++;
        break;
        case 10:
        case 'k':
        count--;
        break;
    }

var holdbet = 'hold'
if(count>0) {
    holdbet = 'bet'
}
//return count + ' ' + holdbet;
}
cc(2); cc(1); cc('k'); cc(10);
//console.log(cc(2));

// Object
var object= {
    object1 : 'alu',
    object2 : 'tamatar',
    16 : 'pyaz'
};
var obj1 = object.object1;
//console.log(obj1);
var obj2 = object['object2'];
var playerNumber = 16;
var player = object[playerNumber]; //it did not work with alphabet 
//console.log(player);

// Lookup object
function lookup(value) {
    var result =''
    var objects = {
        'one' : 1,
        2: 'two'
    }
    result=objects[value];
    return result;
}
//console.log(lookup(2));

// has own property
var moarobject = {
    anotherobject : 'yes',
    anotherone : 'yup'
};
function checkobject(chkprop) {
    if (moarobject.hasOwnProperty(chkprop)) {
    //return moarobject[chkprop]; // with dot it not work
    }
    else {
    //return 'nan';
}
}
//console.log(checkobject('anotherone'));

// Nested Objects
var myStorage = {
    "car": {
        "inside": {
            "glove box": "maps",
        },
        "outside": {
            "trunk": "jack"
        }
    }
};
var gloveBoxContents = myStorage.car.inside["glove box"];
//console.log(gloveBoxContents);

// Record
var collection = {
    '2468': {
        'artist': 'tt',
        'yeat': '901',
        'track': ['vdevs', 'asdasd']
    },
    '5901': {
        'artist': 'wtt',
        'yeat': '9031',
        'track': ['yoreyoma', 'olaola']
    }
}
var copyofcollection = JSON.parse(JSON.stringify(collection));

function updatecollection(id, prop, Value) {
    if(Value === "") {
       delete collection[id][prop];
    }
    else if(prop === "track") {
        collection[id][prop] = collection[id][prop] || [];
        collection[id][prop].push(Value);
    }
    else {
    collection[id][prop] = Value;
    }
    //return collection;
}
//console.log(updatecollection('5901','year', '9'));


// While loop
var myArr = [];
var i= 0;
while(i<5) {
    myArr.push(i);
    i=i+1;
    //i++;
    //i+=1;
} 
//console.log(myArr);


// Iterate through an array with a for loop
var total=0;
var Myarr = [1,3,4,3];
for(var i=0;i<Myarr.length;i++) {
    total+= Myarr[i]
}
//console.log(total);

// Profile lookup
var contacts = [
    {
        'firstname': 'ta',
        'lastname': 'ba',
        'number': '3'
    },
    {
        'firstname': 'qw',
        'lastname': 'er',
        'number': '2'
    }
];
function prolookup(name, prope) {
    for(var i = 0; i < contacts.length ; i++) {
    if(contacts[i].firstname === name) {
        //return contacts[i][prope] || 'nan';
    }
}
//return 'not a property';
}
var data = prolookup('qw', 'lastname');
//console.log(data);


// Round off number
function randomwholenum() {
    //return Math.floor(Math.random() * 10);
}
//console.log(randomwholenum());

function maxminwholenum(mymax, mymin){
    //return Math.floor(Math.random() * (mymax - mymin + 1 ) + mymin)
}
//console.log(maxminwholenum(5,15));
function parsing(str) {
    //return parseInt(str)
}
//console.log('56');


// Multi Ternary Operator
function ternary(num) {
    //return num>0 ? 'Positive' : num < 0 ? 'Negative' : 'Zero    '
}
//console.log(ternary(0));


// Const 
function d(stri) { // objects & arrays can be mutated if declared with const keyword
    "use strict";

    const sentence = stri + ' is cool';
    for(let i = 0; i<stri.length; i+=2) {
        //console.log(sentence);
    }
}
//d('Taha')


// Object freeze
function objfreeze() {
    "use strict";
    const MathsConsonant = {
        PI : 3.14
    };
    Object.freeze(MathsConsonant);
    try{
        MathsConsonant.PI = 3.1416789;
    }
    catch(exeption)
    {
        //console.log(exeption)
    }
    //return MathsConsonant;
}
const newobj = objfreeze(); 
//console.log(newobj);


// Arrow function
// let nm = () =>
//     new variable();
// let myConcat = () => 
//     arr1.concat(arr2);
let summ = (function() {
    return function summ(...args) {
        return args.reduce((a,b) => a+b,0);
    };
})();
//console.log(summ(1,2,3));


// Destructuring Assignment
const temperature = {
    today: 77,
    tomorrow: 70
};
function gettempoftomorrow() {
    "use strict";
    const{tomorrow:newtemp} = temperature;
    return newtemp;
}
//console.log(gettempoftomorrow(temperature));

/* does not work
let temp = {
    today: 38,
    tomorrow: 35
};
let gettempoftom = () => (tomorrow);

console.log(gettempoftom(temp)); */

const tem = {
    toda: 38,
    tomorro: 35
};
const gettempof = (function() {
    return function gettempof({toda}) {
        return (toda);
    };
})();

//console.log(gettempof(tem));

// Template Literals
const person = {
    profession: 'IT',
    age:25
};
const ger = `hy my profession is ${person.profession} and age is ${person.age}`;
//console.log(ger);

const result = {
    failure: ['qw','qe','qr'],
    passed:[2017,2021,2022]
};
function makeList(arr) {
    const resultDisplayArray = [];
    for(let i=0; i<arr.length;i++) {
        resultDisplayArray.push(`<li class="text-warning">${arr[i]}</li>`)
    }
    return resultDisplayArray;
}
const resultDisplayArray = makeList(result.failure);
//console.log(resultDisplayArray);

// Simple fields
const run = (names,age, gender) => {
    return {
        names: names,
        age: age,
        gender: gender
    };
}
//console.log(runk('taha','23','m'));

const funk = (name, age, gender) => ({name,age,gender})
//console.log(runk('taha','23','M'));

// Class Syntax
const bike = {
    color : 'black',
    applycolor : function(newcolor) {
        "use strict";
        this.color = newcolor;  
    }
};
bike.applycolor('white');
//console.log(bike.color);

//
// var var1 = function(newvar) {
//     this.newvar = newvar; 
// }
// var bom = new var1('jo')
// console.log(bom.newvar);

class first {
    constructor(con) {
        this.con = con;
    }   
}
var zeis = new first('a');
//console.log(zeis.con);

class spaceshuttle{
    constructor(newplanet) {
        this.newplanet = newplanet;
    }
}
var zeus = new spaceshuttle('Uranus');
//console.log(zeus.newplanet);
// function () {
//     class  {
//         constructor(newtemparature) {
//             this._newtemperature = 9/(newtemparature);
//         }
//     set newtemparature
//     }
// }
function makeclass() {
    class thermostat{
        constructor(temp) {
            this._temp = 9*(temp);
        }
         get temperature() {
            return this._temp;
         }
         set temperature(updatedtemp) {
            this._temp = updatedtemp;
         }
    }
    return thermostat
}
const thermostat = makeclass();
const thermos = new thermostat(4);
let temp=thermos.temperature; 
thermos.temperature = 36;
temp = thermos.temperature;
//console.log(temp);
function one() {
    class two {
        constructor(three) {
            this._three = 3/(three);
        }
        get four() {
            return this._three;
        }
        set four(updatedthree) {
            this._three = updatedthree;
        }
    }
    return two;
}
const two = one();
const five = new two(30);
let three = five.four;
five.four=10;
three = five.four;
// console.log(three);

var div,
container = document.getElementById("container");
for(var i=0; i<5; i++)
{
    // div = document.createElement("div");
    // div.onclick = function() {
    // alert("hey" + i)
    // };
    // container.appendChild(div);
}

var logCompliment = function(look) {
    // console.log("I am", `${look}`) 
}
// logCompliment("handsome");
//  console.log(logCompliment('handsome')); this also works

// default values/dynamic variables/arguments/parameters.

// var defaultparameters = {
//     firstname : 'alex',
//     message : 'call me'
// };
// function param(){
//     defaultparameters = newparameters;
//     newparameters(`${firstname} ${message}`);
// }
// console.log(newparameters);

const persons = (firstname) => ({
        fir:firstname 
});
//console.log(persons('bwar'));

const tahoe = {
    montains : ['a1','c3','v5','b6'],
     print: function(delay = 1000) {
        setTimeout(() => {
            //console.log(this.montains.join(' ,') /*, delay*/)
        }, delay)
    }
};
//tahoe.print();

const sandwhich = {
    meat: 'beaf',
    bread: 'braun', 
    toppings: ['cheese', 'mayo', 'ketchup', 'meat']
}

const {bread, meat} = sandwhich;

//bread = 'fresh';
//console.log(bread);
//console.log(sandwhich.bread);

const nerdify = regularperson => {
    //console.log(`${regularperson.firstname} of cantersbury`)
};
const regularperson ={
    firstname: 'mo',
    lastname: 'ohw'
}
//nerdify(regularperson);

const noobify = ({firstname}) => {
    //console.log(`${firstname} of petersburg`)
}
const nonregularperson ={
    firstname: 'owe',
    lastname: 'ow'
}
//noobify(nonregularperson);

// const sweeper = {(spouse: (firstname))}

// const genre = {
//     name,
//     sound,

// poweryell() {
//     var yell = this.sound.toUpperCase();
//     console.log(`${yell}`);
// },
// speed(mph) {
//   this.speed = mph;
//   console.log("sound", mph);
// }
// };

// console.log(fetch("https://api.randomuser.me/?nat=US&results=1"));

let foo = {};
foo.name = 'holy;'
//console.log(foo);

//Enumerate
//object.keys({nem:"gy", aeh: 2}) = ["nem", "aeh"];

a = {a:'at', b:'c', c : 'd'}
var s = '';
for ( var key in a)
{
    s += [key] + ': ' + a[key];
    s += '<br/>';
}
//document.write(s);

c = ['gred', 'ja']
for (let i of c)
{
    //document.write(c);
}

var m = new Map();
m.set(1,'sw');
m.set(2,'gt');
for(var n of m) {
    //document.write(n)
}

//document.getElementById('secondcontainer').innerHTML =  '<p>new</p>';
//document.getElementById('secondcontainer').innerHTML =  'yp'

//document.getElementById('thirdcontainer').onclick()
setInterval(()=> thirdcontainer.hidden = !thirdcontainer.hidden, 1000);

const peaks = ["Tallac", "Ralston", "Rose"];
const [firstS] = peaks.reverse();
//console.log(firstS); // Rose
//console.log(peaks.join(", "));
